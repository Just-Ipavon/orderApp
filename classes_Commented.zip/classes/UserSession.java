package com.example.orderapp.classes;
//Classe per gestire la session utente
public class UserSession {
    private static UserSession instance; //Statica per essere richiamata anche fuori dalla classe
    private String username;
    private boolean isAdmin;
    //Costruttore
    private UserSession(String username, boolean isAdmin) {
        this.username = username;
        this.isAdmin = isAdmin;
    }
    //Getter per ottenere l'istanza - controllo admin
    public static UserSession getInstance(String username, Boolean isAdmin) {
        instance = new UserSession(username, isAdmin);
        return instance;
    }
    public static UserSession getInstance() {
        return instance;
    }

    public String getUsername() {
        return username;
    }

    public boolean isAdmin() {
        return isAdmin;
    }

    public void cleanUserSession() {
        if(instance!=null){
            username = "";
            isAdmin = false;
            instance = null;
        }
    }
    //Stampa della session in stringa
    @Override
    public String toString() {
        return "UserSession{" +
                "username='" + username + '\'' +
                ", isAdmin=" + isAdmin +
                '}';
    }
}
