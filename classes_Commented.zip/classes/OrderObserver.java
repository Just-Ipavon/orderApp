package com.example.orderapp.classes;
//Interfaccia del pattern Observer - Gestisce i cambiamenti all'ordine, quindi la consegna al tavolo
public interface OrderObserver {
    void onOrderStatusChanged(int orderId, boolean delivered);
    void onOrderDeleted(int orderId);
    void onDishDeleted(int orderId, int menuId);
    void onPaymentProcessed(int orderId, int transactionId, String paymentMethod, double amountReceived);
}
