package com.example.orderapp.classes;
import javafx.scene.shape.Rectangle;
//Classe tavolo, per gestire i "clienti"
public class Table {
    private final int tableId;
    private final int numberOfSeats;
    private Rectangle rectangle;

    public Table(int tableId, int numberOfSeats) {
        this.tableId = tableId;
        this.numberOfSeats = numberOfSeats;
    }
    //Metodi get
    public int getTableId() {
        return tableId;
    }

    public int getNumberOfSeats() {
        return numberOfSeats;
    }
    //Metodi per gestire la UI del tavolo
    public Rectangle getRectangle() {
        return rectangle;
    }

    public void setRectangle(Rectangle rectangle) {
        this.rectangle = rectangle;
    }
}
