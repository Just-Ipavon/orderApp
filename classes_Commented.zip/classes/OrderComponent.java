package com.example.orderapp.classes;

//Interfaccia che gestisce le "parti" dell'ordine - i piatti singoli
public interface OrderComponent {
    int getMenuId();
    String getDishName();
    double getDishPrice();
    int getQuantity();
    void incrementQuantity();
    void setQuantity(int quantity);
    double getTotalPrice();
    String getNotes();
    void setNotes(String notes);
}
