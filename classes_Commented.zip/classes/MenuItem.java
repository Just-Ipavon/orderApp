package com.example.orderapp.classes;

//Classe per gestire i piatti
public class MenuItem {
    private final int menuId;
    private final String name;
    private final double price;
    //Costruttore
    public MenuItem(int menuId, String name, double price) {
        this.menuId = menuId;
        this.name = name;
        this.price = price;
    }
    //Metodi get, i set sono implementati dal programmatore che dà i nomi ai piatti
    public int getMenuId() {
        return menuId;
    }
    public String getName() {
        return name;
    }
    public double getPrice() {
        return price;
    }
}
