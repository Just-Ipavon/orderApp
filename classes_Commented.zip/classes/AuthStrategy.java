package com.example.orderapp.classes;
//Interfaccia per l'autenticazione, che usa Strategy
public interface AuthStrategy {
    UserSession authenticate(String userId, String password);
}
