package com.example.orderapp.classes;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

//Classe per il completamento dell'ordine
public class CompleteOrder {
    private final int orderId;
    private final int tableId;
    private boolean delivered;
    private boolean completed;
    private List<Order> dishes;
    private String paymentMethod;
    private Timestamp transactionDate;
    private double paymentAmount; //Per Strategy
    //Costruttore
    public CompleteOrder(int orderId, int tableId) {
        this.orderId = orderId;
        this.tableId = tableId;
        this.delivered = false;
        this.completed = false;
        this.dishes = new ArrayList<>();
        this.paymentAmount = 0.0; // Inizializzazione
    }
    //Metodi Get
    public int getOrderId() {
        return orderId;
    }
    public int getTableId() {
        return tableId;
    }
    public List<Order> getDishes() {
        return dishes;
    }
    public double getTotalPrice() {
        return dishes.stream().mapToDouble(Order::getTotalPrice).sum();
    }
    public String getPaymentMethod() {
        return paymentMethod;
    }
    public double getPaymentAmount() {
        return paymentAmount;
    }
    public Timestamp getTransactionDate() {
        return transactionDate;
    }
    //Controllo se l'ordine è consegnato al cliente
    public boolean isDelivered() {
        return delivered;
    }
    //Controllo se l'ordine è completato (pagato)
    public boolean isCompleted() {
        return completed;
    }
    //Metodi set
    public void setDelivered(boolean delivered) {
        this.delivered = delivered;
    }
    public void setCompleted(boolean completed) {
        this.completed = completed;
    }
    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
    public void setTransactionDate(Timestamp transactionDate) {
        this.transactionDate = transactionDate;
    }
    public void setPaymentAmount(double paymentAmount) {
        this.paymentAmount = paymentAmount;
    }
    //Metodo per aggiungere un piatto all'ordine
    public void addDish(Order order) {
        this.dishes.add(order);
    }
}
