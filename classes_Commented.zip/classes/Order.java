package com.example.orderapp.classes;

//Classe che gestisce ciascun order
public class Order implements OrderComponent {
    private final int menuId;
    private final String dishName;
    private final double dishPrice;
    private int quantity;
    private String notes;
    //Costruttore, gestiamo anche possibili note
    public Order(int menuId, String dishName, double dishPrice) {
        this.menuId = menuId;
        this.dishName = dishName;
        this.dishPrice = dishPrice;
        this.quantity = 1;
        this.notes = "";
    }
    //Metodi get
    @Override
    public String getDishName() {
        return dishName;
    }
    @Override
    public double getDishPrice() {
        return dishPrice;
    }
    @Override
    public int getMenuId() {
        return menuId;
    }
    @Override
    public int getQuantity() {
        return quantity;
    }
    @Override
    public double getTotalPrice() {
        return this.dishPrice * this.quantity;
    }
    @Override
    public String getNotes() {
        return notes;
    }
    //Metodo per aumentare la quantità di un ordine
    @Override
    public void incrementQuantity() {
        this.quantity++;
    }
    //Metodi set
    @Override
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    @Override
    public void setNotes(String notes) {
        this.notes = notes;
    }
}
